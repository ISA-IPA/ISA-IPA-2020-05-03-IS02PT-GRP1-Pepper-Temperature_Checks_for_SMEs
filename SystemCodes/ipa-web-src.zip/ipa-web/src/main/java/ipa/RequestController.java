package ipa;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ipa.dto.EmployeeDto;

import java.io.*;
import java.util.*;

@Controller
public class RequestController {

    EmployeeDto employeeDto;

    File employeeFile = new File("employee.csv");

    static Properties configProp = new Properties();
    static {
        try {
            configProp.load(
                    new FileReader(new File("config.properties"))
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @RequestMapping("/")
    public String welcome() {
        return "index";
    }


    @GetMapping("/backToMain")
    public String goToMain() throws Exception{
        return "redirect:/";
    }

    @GetMapping("/go_to_details_input")
    public String goToDetailsInput(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
        model.addAttribute("name", name);
        EmployeeDto preferenceDto = new EmployeeDto();
        model.addAttribute("employeeDto", preferenceDto);

        List<EmployeeDto> employeeList = new ArrayList<>();
        try {
            if (employeeFile.exists()) {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(employeeFile));
                String line;
                while ( (line = bufferedReader.readLine()) != null) {
                    if( line.trim().length() > 0 ) {
                        String[] strArr = line.split(",");
                        EmployeeDto employeeDto = new EmployeeDto(strArr[0], strArr[1], strArr[2], strArr[3]);
                        employeeList.add(employeeDto);
                    }
                }
                bufferedReader.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        model.addAttribute("employeeList", employeeList);

        return "details_input";
    }

    @PostMapping("/submit_employee")
    public String submitEmployee(@ModelAttribute EmployeeDto employeeDto, Model model) {

        this.employeeDto = employeeDto;
        try {

            if(!employeeFile.exists()) {
                employeeFile.createNewFile();
            }
            BufferedWriter output = new BufferedWriter(new FileWriter(employeeFile, true));
            output.write(employeeDto.toCSVString());
            output.newLine();
            output.flush();
            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "redirect:/go_to_details_input";
    }


    @GetMapping("/start_process")
    public String startProcess(Model model) {

        /*
        String uiRobotPath = "C:\\Users\\gary\\AppData\\Local\\UiPath\\app-19.12.0-beta0061\\UiRobot.exe";
        String command = "execute --file";
        String filePath = "C:\\Users\\gary\\OneDrive\\Documents\\UiPath\\test_process_20200410\\Sequence.xaml";
        */

        String uiRobotPath = configProp.getProperty("uiRobot_path").trim();
        String uiPathCommand = configProp.getProperty("uiPath_command").trim();
        String filePath = configProp.getProperty("uiPath_file").trim();

        String finalCommand = uiRobotPath + " " + uiPathCommand + " " + filePath;
        System.out.println(finalCommand);
        try {
            Runtime.getRuntime().exec(finalCommand);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("command executed successfully");
        return "redirect:/";
    }

    @GetMapping("/start_temperature_process")
    public String startTemperatureProcess(Model model) throws Exception {

        String uiRobotPath = configProp.getProperty("uiRobot_path").trim();
        String uiPathCommand = configProp.getProperty("uiPath_command").trim();
        String filePath = configProp.getProperty("uiPath_file").trim();

        String finalCommand = uiRobotPath + " " + uiPathCommand + " " + filePath;
        System.out.println(finalCommand);
        try {
            Runtime.getRuntime().exec(finalCommand);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("startTemperatureProcess successfully");
        return "redirect:/";
    }

    /*@GetMapping("/start_temperature_process")
    public String startTemperatureProcess(Model model) {

        String windowsCmd = configProp.getProperty("windows_command").trim();
        String pythonExe = configProp.getProperty("temperature_python_exe").trim();
        String filePath = configProp.getProperty("temperature_python_file").trim();

        String finalCommand = windowsCmd + " " + pythonExe + " " + filePath;
        System.out.println(finalCommand);
        try {
            Runtime.getRuntime().exec(finalCommand);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("startTemperatureProcess successfully");
        return "redirect:/";
    }*/

    @GetMapping("/stop_process")
    public String stopProcess(Model model) {

        List<String> processList = Arrays.asList(configProp.getProperty("process_list").trim().split(";"));

        processList.forEach(
                process -> {
                    String command = "taskkill /IM \"" + process + "\" /F";
                    try {
                        Runtime.getRuntime().exec(command);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println(command);
                }
        );

        System.out.println("stopProcess completed successfully");
        return "redirect:/";
    }

    @GetMapping("/get_latest_login")
    public String getLatestLogin(Model model) throws Exception {
        Map<String, String> map = CSVUtils.getLatestLoginEmployee();
        /*model.addAttribute("Name", map.get(CSVUtils.KEY_NAME));
        model.addAttribute("Time", map.get(CSVUtils.KEY_TIME));*/

        if(map.get(CSVUtils.KEY_NAME).trim().length() > 0) {
            String lastAccess = "Last access:";
            String name = map.get(CSVUtils.KEY_NAME);
            String time = map.get(CSVUtils.KEY_TIME);
            String temperature = map.get(CSVUtils.KEY_TEMPERATURE);
            String str = lastAccess + " " + name + " " + time + " ,Temperature:" + temperature;

            Set<String> blackList = CSVUtils.getBlackList();
            if( blackList.contains(name) ) {
                str = "You are supposed to be in isolation. Please stay here and someone will look for you.";
            }
            model.addAttribute("model_value_employeeNameAndTime", str);
            System.out.println("getLatestLogin============" + str);
        }
        //return "myview :: #employeeNameAndTime";
        return "index::#employeeNameAndTime";
    }

    /*@RequestMapping(value="/event-count", method=RequestMethod.GET)
    public String getEventCount(ModelMap map) {
        // TODO: retrieve the new value here so you can add it to model map
        map.addAttribute("numDeviceEventsWithAlarm", count);

        // change "myview" to the name of your view
        return "myview :: #eventCount";
    }*/
}
